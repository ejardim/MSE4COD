### Name: FLXSA
### Title: Create a new FLXSA object -run an XSA analysis-
### Aliases: FLXSA
### Keywords: classes

### ** Examples


#TO DO...




