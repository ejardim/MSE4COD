### Name: FLSepVPA.control-class
### Title: Control class for FLSepVPA
### Aliases: FLSepVPA.control-class FLSepVPA.control
### Keywords: classes

### ** Examples

sep.vpa.control <- FLSepVPA.control(sep.nyr=5, sep.age=5)



